import React from 'react';
import { View, Text } from 'react-native';

export default class TelaHomeApp extends React.Component{

    render(){

        return(

            <View>

                <Text>Parabêns você se logou</Text>

            </View>

        );

    }

}